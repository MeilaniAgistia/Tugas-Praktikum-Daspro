#include <iostream>
#include <conio.h>
#include <string>
using namespace std;

int main()
{
  int kamar, harga, lama, bayar;
  string nkamar;

  cout<<"==PENYEWAAN KAMAR HOTEL=="<<endl;
  cout<<endl;
  cout<<"No Jenis Kamar Harga "<<endl<<"1.Standart Room Rp:500.000"<<endl<<"2.Deluxe Room Rp:1.000.000"<<endl<<"3.Accessible Room Rp:1.500.000"<<endl;
  cout<<"==========================="<<endl;
  cout<<endl;
  system ("clear");
  cout<<"Pilih Jenis kamar yang anda inginkan : ";
  cin>>kamar;  
  if (kamar==1)
  {
    harga=500000;
    nkamar="standart room";
  }
  else if (kamar==2)
  {
    harga=1000000;
    nkamar="Deluxe Room";
  }
  else if (kamar==3)
  {
    harga=1500000;
    nkamar="Accessible Room.";
  }  
  cout<<"Kamar yang anda pilih adalah "<<nkamar<<" dengan harga Rp:"<<harga<<"/Hari"<<endl;
  cout<<"Berapa lama anda ingin menyewa kamar tersebut : ";
  cin>>lama;
  bayar=lama*harga; 
  cout<<endl;
  cout<<"Jenis kamar pilihan anda : "<<nkamar<<endl;
  cout<<"Lama penyewaan anda "<<lama<<" hari"<<endl;
  cout<<"Total harga penyewaan yang harus anda bayar adalah  Rp;"<<bayar<<endl;

getch(); 
}



